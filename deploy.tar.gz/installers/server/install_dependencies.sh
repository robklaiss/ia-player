#!/bin/bash
# Install system dependencies
sudo apt update && sudo apt install -y \
  python3 \
  python3-venv \
  mpv
