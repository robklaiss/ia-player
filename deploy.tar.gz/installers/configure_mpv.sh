#!/bin/bash
# Configure MPV player
mkdir -p ~/.config/mpv
echo 'volume=100
save-position-on-quit=yes' > ~/.config/mpv/mpv.conf
